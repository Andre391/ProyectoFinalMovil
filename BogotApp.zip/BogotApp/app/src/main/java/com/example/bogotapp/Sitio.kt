package com.example.bogotapp

data class Sitio (val nombre: String, val foto: String,val desc:String) {

}
